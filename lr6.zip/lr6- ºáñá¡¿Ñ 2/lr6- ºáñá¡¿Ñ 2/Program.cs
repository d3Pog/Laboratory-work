﻿using System;

// Базовый класс для обработчика операции
abstract class OperationHandler
{
    protected OperationHandler successor;

    public void SetSuccessor(OperationHandler successor)
    {
        this.successor = successor;
    }

    public abstract void HandleRequest(string request);
}

// Классы для конкретных обработчиков
class TransferHandler : OperationHandler
{
    public override void HandleRequest(string request)
    {
        if (request == "Перевод")
        {
            Console.WriteLine("Обработка запроса на перевод");
        }
        else
        {
            successor?.HandleRequest(request);
        }
    }
}

class PaymentHandler : OperationHandler
{
    public override void HandleRequest(string request)
    {
        if (request == "Оплата")
        {
            Console.WriteLine("Обработка запроса на оплату");
        }
        else
        {
            successor?.HandleRequest(request);
        }
    }
}

class TopUpHandler : OperationHandler
{
    public override void HandleRequest(string request)
    {
        if (request == "Пополнение")
        {
            Console.WriteLine("Обработка запроса на пополнение");
        }
        else
        {
            Console.WriteLine("Неподдерживаемая операция");
        }
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Создание цепочки обработчиков
        TransferHandler transferHandler = new TransferHandler();
        PaymentHandler paymentHandler = new PaymentHandler();
        TopUpHandler topUpHandler = new TopUpHandler();

        transferHandler.SetSuccessor(paymentHandler);
        paymentHandler.SetSuccessor(topUpHandler);

        // Тестирование цепочки обработчиков
        string[] requests = { "Перевод", "Оплата", "Пополнение", "Запрос" };

        foreach (var request in requests)
        {
            transferHandler.HandleRequest(request);
        }
    }
}