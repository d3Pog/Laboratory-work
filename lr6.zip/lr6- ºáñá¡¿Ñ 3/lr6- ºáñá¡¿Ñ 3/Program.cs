﻿using System;

// Интерфейс для команды
interface ICommand
{
    void Execute();
}

// Классы для конкретных команд
class LightOnCommand : ICommand
{
    private Light light;

    public LightOnCommand(Light light)
    {
        this.light = light;
    }

    public void Execute()
    {
        light.TurnOn();
    }
}

class LightOffCommand : ICommand
{
    private Light light;

    public LightOffCommand(Light light)
    {
        this.light = light;
    }

    public void Execute()
    {
        light.TurnOff();
    }
}

class ThermostatSetCommand : ICommand
{
    private Thermostat thermostat;
    private int temperature;

    public ThermostatSetCommand(Thermostat thermostat, int temperature)
    {
        this.thermostat = thermostat;
        this.temperature = temperature;
    }

    public void Execute()
    {
        thermostat.SetTemperature(temperature);
    }
}

// Классы устройств умного дома
class Light
{
    public void TurnOn()
    {
        Console.WriteLine("Освещение включено");
    }

    public void TurnOff()
    {
        Console.WriteLine("Освещение выключено");
    }
}

class Thermostat
{
    public void SetTemperature(int temperature)
    {
        Console.WriteLine($"Температура установлена на {temperature} градусов");
    }
}

class Program
{
    static void Main(string[] args)
    {
        // Создание объектов
        Light light = new Light();
        Thermostat thermostat = new Thermostat();

        // Создание команд
        ICommand lightOnCommand = new LightOnCommand(light);
        ICommand lightOffCommand = new LightOffCommand(light);
        ICommand thermostatSetCommand = new ThermostatSetCommand(thermostat, 25);

        // Выполнение команд
        lightOnCommand.Execute();
        lightOffCommand.Execute();
        thermostatSetCommand.Execute();
    }
}
