﻿using System;
using System.Collections.Generic;

// Интерфейс для наблюдателя
interface IObserver
{
    void Update(string message);
}

// Класс для интернет-магазина, рассылающего уведомления
class OnlineStore
{
    private List<IObserver> observers = new List<IObserver>();

    // Метод для добавления подписчика
    public void Attach(IObserver observer)
    {
        observers.Add(observer);
    }

    // Метод для удаления подписчика
    public void Detach(IObserver observer)
    {
        observers.Remove(observer);
    }

    // Метод для отправки уведомлений
    public void Notify(string message)
    {
        foreach (var observer in observers)
        {
            observer.Update(message);
        }
    }
}

// Класс для клиентов, подписывающихся на уведомления
class Client : IObserver
{
    private string name;

    public Client(string name)
    {
        this.name = name;
    }

    // Метод для обновления клиента о новом заказе
    public void Update(string message)
    {
        Console.WriteLine($"Уважаемый клиент {name}, у нас новый заказ: {message}");
    }
}

class Program
{
    static void Main(string[] args)
    {
        OnlineStore store = new OnlineStore();
        Client client1 = new Client("Иван");
        Client client2 = new Client("Мария");

        // Подписка клиентов на уведомления
        store.Attach(client1);
        store.Attach(client2);

        // Создание нового заказа и отправка уведомления
        string newOrder = "Заказ №12345";
        store.Notify(newOrder);

        // Отписка одного из клиентов
        store.Detach(client1);

        // Создание еще одного заказа и отправка уведомления
        string newOrder2 = "Заказ №54321";
        store.Notify(newOrder2);
    }
}
